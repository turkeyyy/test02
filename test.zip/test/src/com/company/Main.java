package com.company;

public class Main {

    public static void main(String[] args) {

         int a=1000;
        if(a%4==0 && a%100!=0 || a%400==0){
        System.out.println("a是闰年");
          }else{
        System.out.println("a不是闰年");}

    }
}
