package digui;

import java.util.Scanner;

public class a {
    public static void main(String[] args) {
        while (true) {
            System.out.println("请输入一个五位数");
            Scanner sc = new Scanner(System.in);
            int a = sc.nextInt();
            if (a == 0) {
                break;
            }else{
                if (a >= 10000 && a <= 99999) {
                    digui(a);
                }else{
                    System.out.println("这并不是五位数");
                }
            }
        }
    }
//递归：方法的自我调用

    public static void digui(int a) {
        if (a<=0)return;

            System.out.print(a % 10);
            digui(a / 10);

    }
}

