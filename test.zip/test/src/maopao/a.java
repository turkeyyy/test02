package maopao;

import java.util.Set;
import java.util.Random;
import java.util.HashSet;

public class a {
    public static void main(String[] args) {
        Random r = new Random();
        int[] arr = new int[7];
        for (int m = 1; m < 8; m++)//生成七次
        {
            int f = 0;
            int b = r.nextInt(30);
            for (int i = 0; i < arr.length; i++)//判断是否重复
            {
                if (b == arr[i]) {
                    f = 1;
                }
            }
            if (f == 0) {
                arr[m - 1] = b;
            } else if (f == 1) {
                m -= 1;
            }
        }
        for (int i = 1; i < arr.length; i++) {
            for (int j = 0; j < arr.length - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
        for (int w = 0; w < 7; w++) {
            System.out.println(arr[w]);
        }
    }
}

