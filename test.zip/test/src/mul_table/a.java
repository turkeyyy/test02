package mul_table;

public class a {
    public static void main(String[] arges) {
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "*" + i + "=" + (i * j) + " ");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j < 11 - i; j++) {
                System.out.print(j + "*" + i + "=" + (i * j) + " ");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 1; i <= 9; i++) {//设置外循环i，控制行数
            for (int k = 1; k < i; k++) {//内层循环k,控制每行空格数
                System.out.print("        ");//每一行输出八个空格
            }
            for (int j = i; j <= 9; j++) {//内循环，控制列数
                System.out.print(i + "*" + j + "=" + (i * j) + "\t");
            }
            System.out.println();//每操作完一行换行
        }
        System.out.println();
        for (int i = 1; i <= 9; i++) {//设置外循环i，控制行数
            for (int j = i; j <= 9; j++) {//内循环，控制列数
                System.out.print(i + "*" + j + "=" + (i * j) + "\t");
            }
            for (int k = 1; k < i; k++) {//内层循环k,控制每行空格数
                System.out.print("        ");//每一行输出八个空格
            }
            System.out.println();//每操作完一行换行
        }

    }
}
