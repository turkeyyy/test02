package suiji;

import java.util.Random;
import java.util.Scanner;

public class a {
public static void main(String[] args) {
    Random r = new Random();
    int a = r.nextInt(100);
    System.out.println(a);
    for (int i = 3; i >0; i--) {
        System.out.println("请输入一个100以内的数");
        Scanner sc = new Scanner(System.in);
        int b = sc.nextInt();
        if (b == a) {
            System.out.println("您猜对了");
        } else {
           int k=i-1;
            System.out.println("您还剩余"+k+"次机会");
        }
    }
}
}
