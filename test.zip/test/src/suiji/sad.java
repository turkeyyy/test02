package suiji;
import java.util.Random;
import java.util.Scanner;
public class sad {
    public static void main(String[] args) {
        Random r = new Random();
        int[] arr = new int[7];
        for (int m = 1; m < 8; m++)//生成七次
        {
            int f = 0;
            int b = r.nextInt(30);
            for (int i = 0; i < arr.length; i++)//判断是否重复
            {
                if (b == arr[i]) {
                    f = 1;
                }
            }
            if (f == 0) {
                System.out.println(b);
                arr[m - 1] = b;
            } else if (f == 1) {
                m -= 1;
            }
        }
    }
}
